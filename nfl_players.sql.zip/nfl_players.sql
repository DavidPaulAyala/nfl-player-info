-- phpMyAdmin SQL Dump
-- version 4.6.1
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Oct 03, 2016 at 10:34 PM
-- Server version: 5.7.12
-- PHP Version: 5.6.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nfl_players`
--
CREATE DATABASE IF NOT EXISTS `nfl_players` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `nfl_players`;

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `position` varchar(255) NOT NULL,
  `td` int(11) DEFAULT NULL,
  `team` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`id`, `first_name`, `last_name`, `position`, `td`, `team`) VALUES
(181, 'Dan', 'Bailey', 'K', 0, 'DAL'),
(182, 'Blair', 'Walsh', 'K', 0, 'MIN'),
(183, 'Stephen', 'Gostkowski', 'K', 0, 'NE'),
(184, 'Jason', 'Myers', 'K', 0, 'JAX'),
(185, 'Nick', 'Novak', 'K', 0, 'HOU'),
(186, 'Mike', 'Nugent', 'K', 0, 'CIN'),
(187, 'Adam', 'Vinatieri', 'K', 0, 'IND'),
(188, 'Matt', 'Bryant', 'K', 0, 'ATL'),
(189, 'Nick', 'Folk', 'K', 0, 'NYJ'),
(190, 'Dustin', 'Hopkins', 'K', 0, 'WAS'),
(191, 'Wil', 'Lutz', 'K', 0, 'NO'),
(192, 'Mason', 'Crosby', 'K', 0, 'GB'),
(193, 'Josh', 'Lambo', 'K', 0, 'SD'),
(194, 'Cairo', 'Santos', 'K', 0, 'KC'),
(195, 'Caleb', 'Sturgis', 'K', 0, 'PHI');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=196;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
