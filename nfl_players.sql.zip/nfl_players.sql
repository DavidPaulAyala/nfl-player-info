-- phpMyAdmin SQL Dump
-- version 4.6.1
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Oct 04, 2016 at 03:36 PM
-- Server version: 5.7.12
-- PHP Version: 5.6.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nfl_players`
--
CREATE DATABASE IF NOT EXISTS `nfl_players` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `nfl_players`;

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `position` varchar(255) NOT NULL,
  `team` varchar(255) NOT NULL,
  `ff_points` float NOT NULL,
  `pass_yds` int(11) NOT NULL,
  `pass_tds` int(11) NOT NULL,
  `rush_yds` int(11) NOT NULL,
  `rush_tds` int(11) NOT NULL,
  `rec_yds` int(11) DEFAULT NULL,
  `rec_tds` int(11) NOT NULL,
  `intercepts` int(11) NOT NULL,
  `fum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`id`, `first_name`, `last_name`, `position`, `team`, `ff_points`, `pass_yds`, `pass_tds`, `rush_yds`, `rush_tds`, `rec_yds`, `rec_tds`, `intercepts`, `fum`) VALUES
(226, 'Andrew', 'Luck', 'QB', 'IND', 35.5, 385, 4, 21, 0, NULL, 0, 0, 0),
(227, 'Drew', 'Brees', 'QB', 'NO', 31.42, 423, 4, 5, 0, NULL, 0, 0, 1),
(228, 'Alex', 'Smith', 'QB', 'KC', 28.02, 363, 2, 15, 1, NULL, 0, 1, 0),
(229, 'Matthew', 'Stafford', 'QB', 'DET', 26.1, 340, 3, 5, 0, NULL, 0, 0, 0),
(230, 'Jameis', 'Winston', 'QB', 'TB', 25.54, 281, 4, 3, 0, NULL, 0, 1, 0),
(231, 'Matt', 'Ryan', 'QB', 'ATL', 24.36, 334, 2, 10, 0, NULL, 0, 0, 0),
(232, 'Aaron', 'Rodgers', 'QB', 'GB', 23.56, 199, 2, 16, 1, NULL, 0, 0, 0),
(233, 'Derek', 'Carr', 'QB', 'OAK', 22.36, 319, 1, 16, 0, NULL, 0, 0, 0),
(234, 'Ben', 'Roethlisberger', 'QB', 'PIT', 21.8, 300, 3, -2, 0, NULL, 0, 1, 0),
(235, 'Cam', 'Newton', 'QB', 'CAR', 21.16, 194, 1, 54, 1, NULL, 0, 1, 0),
(236, 'Carson', 'Wentz', 'QB', 'PHI', 19.22, 278, 2, 1, 0, NULL, 0, 0, 0),
(237, 'Carson', 'Palmer', 'QB', 'ARI', 18.94, 271, 2, 1, 0, NULL, 0, 0, 0),
(238, 'Eli', 'Manning', 'QB', 'NYG', 18.28, 207, 3, 0, 0, NULL, 0, 1, 0),
(239, 'Andy', 'Dalton', 'QB', 'CIN', 17.34, 366, 1, 7, 0, NULL, 0, 1, 0),
(240, 'Marcus', 'Mariota', 'QB', 'TEN', 16.74, 271, 2, 19, 0, NULL, 0, 1, 1),
(241, 'DeAngelo', 'Williams', 'RB', 'PIT', 29.1, 0, 0, 143, 2, NULL, 0, 0, 0),
(242, 'C.J.', 'Anderson', 'RB', 'DEN', 25.9, 0, 0, 92, 1, NULL, 1, 0, 0),
(243, 'Spencer', 'Ware', 'RB', 'KC', 25.9, 0, 0, 70, 1, NULL, 0, 0, 0),
(244, 'Theo', 'Riddick', 'RB', 'DET', 22.8, 0, 0, 45, 1, NULL, 1, 0, 0),
(245, 'Carlos', 'Hyde', 'RB', 'SF', 21.3, 0, 0, 88, 2, NULL, 0, 0, 0),
(246, 'David', 'Johnson', 'RB', 'ARI', 19.2, 0, 0, 89, 1, NULL, 0, 0, 0),
(247, 'Ameer', 'Abdullah', 'RB', 'DET', 18, 0, 0, 63, 0, NULL, 1, 0, 0),
(248, 'Danny', 'Woodhead', 'RB', 'SD', 18, 0, 0, 89, 0, NULL, 1, 0, 0),
(249, 'Melvin', 'Gordon', 'RB', 'SD', 17.7, 0, 0, 57, 2, NULL, 0, 0, 0),
(250, 'DeMarco', 'Murray', 'RB', 'TEN', 17.7, 0, 0, 42, 0, NULL, 2, 0, 1),
(251, 'Matt', 'Forte', 'RB', 'NYJ', 15.5, 0, 0, 96, 0, NULL, 0, 0, 0),
(252, 'Jalen', 'Richard', 'RB', 'OAK', 15.5, 0, 0, 84, 1, NULL, 0, 0, 0),
(253, 'Isaiah', 'Crowell', 'RB', 'CLE', 13.8, 0, 0, 62, 1, NULL, 0, 0, 0),
(254, 'Ryan', 'Mathews', 'RB', 'PHI', 13.7, 0, 0, 77, 1, NULL, 0, 0, 0),
(255, 'Latavius', 'Murray', 'RB', 'OAK', 13.2, 0, 0, 59, 1, NULL, 0, 0, 0),
(256, 'Brandin', 'Cooks', 'WR', 'NO', 27.4, 0, 0, 11, 0, NULL, 2, 0, 0),
(257, 'Antonio', 'Brown', 'WR', 'PIT', 24.6, 0, 0, 0, 0, NULL, 2, 0, 0),
(258, 'A.J.', 'Green', 'WR', 'CIN', 24, 0, 0, 0, 0, NULL, 1, 0, 0),
(259, 'Willie', 'Snead', 'WR', 'NO', 23.2, 0, 0, 0, 0, NULL, 1, 0, 0),
(260, 'Larry', 'Fitzgerald', 'WR', 'ARI', 20.1, 0, 0, 0, 0, NULL, 2, 0, 0),
(261, 'Jordan', 'Matthews', 'WR', 'PHI', 17.4, 0, 0, 0, 0, NULL, 1, 0, 0),
(262, 'Will', 'Fuller', 'WR', 'HOU', 16.7, 0, 0, 0, 0, NULL, 1, 0, 0),
(263, 'Mike', 'Wallace', 'WR', 'BAL', 16.2, 0, 0, 11, 0, NULL, 1, 0, 0),
(264, 'Mohamed', 'Sanu', 'WR', 'ATL', 16, 0, 0, 0, 0, NULL, 1, 0, 0),
(265, 'Mike', 'Evans', 'WR', 'TB', 15.9, 0, 0, 0, 0, NULL, 1, 0, 0),
(266, 'Amari', 'Cooper', 'WR', 'OAK', 15.7, 0, 0, 0, 0, NULL, 0, 0, 0),
(267, 'Doug', 'Baldwin', 'WR', 'SEA', 15.2, 0, 0, 0, 0, NULL, 1, 0, 0),
(268, 'Kelvin', 'Benjamin', 'WR', 'CAR', 15.1, 0, 0, 0, 0, NULL, 1, 0, 0),
(269, 'Julio', 'Jones', 'WR', 'ATL', 12.6, 0, 0, 0, 0, NULL, 1, 0, 0),
(270, 'Donte', 'Moncrief', 'WR', 'IND', 12.4, 0, 0, 0, 0, NULL, 1, 0, 0),
(271, 'Jack', 'Doyle', 'TE', 'IND', 15.5, 0, 0, 0, 0, NULL, 2, 0, 0),
(272, 'Dwayne', 'Allen', 'TE', 'IND', 13.3, 0, 0, 0, 0, NULL, 1, 0, 0),
(273, 'Julius', 'Thomas', 'TE', 'JAX', 12.4, 0, 0, 0, 0, NULL, 1, 0, 0),
(274, 'Eric', 'Ebron', 'TE', 'DET', 10.6, 0, 0, 0, 0, NULL, 1, 0, 0),
(275, 'Austin', 'Seferian-Jenkins', 'TE', 'NYJ', 9, 0, 0, 0, 0, NULL, 1, 0, 0),
(276, 'Larry', 'Donnell', 'TE', 'NYG', 7.5, 0, 0, 0, 0, NULL, 1, 0, 0),
(277, 'Travis', 'Kelce', 'TE', 'KC', 7.4, 0, 0, 0, 0, NULL, 0, 0, 0),
(278, 'Vance', 'McDonald', 'TE', 'SF', 7.4, 0, 0, 0, 0, NULL, 1, 0, 0),
(279, 'Greg', 'Olsen', 'TE', 'CAR', 7.3, 0, 0, 0, 0, NULL, 0, 0, 0),
(280, 'Jason', 'Witten', 'TE', 'DAL', 6.6, 0, 0, 0, 0, NULL, 0, 0, 0),
(281, 'Kyle', 'Rudolph', 'TE', 'MIN', 6.5, 0, 0, 0, 0, NULL, 0, 0, 0),
(282, 'Brandon', 'Myers', 'TE', 'TB', 6.4, 0, 0, 0, 0, NULL, 1, 0, 0),
(283, 'Jordan', 'Reed', 'TE', 'WAS', 6.4, 0, 0, 0, 0, NULL, 0, 0, 0),
(284, 'C.J.', 'Uzomah', 'TE', 'CIN', 5.9, 0, 0, 0, 0, NULL, 0, 0, 0),
(285, 'Zach', 'Ertz', 'TE', 'PHI', 5.8, 0, 0, 0, 0, NULL, 0, 0, 0),
(286, 'Dan', 'Bailey', 'K', 'DAL', 17, 0, 0, 0, 0, NULL, 0, 0, 0),
(287, 'Blair', 'Walsh', 'K', 'MIN', 15, 0, 0, 0, 0, NULL, 0, 0, 0),
(288, 'Stephen', 'Gostkowski', 'K', 'NE', 13, 0, 0, 0, 0, NULL, 0, 0, 0),
(289, 'Jason', 'Myers', 'K', 'JAX', 13, 0, 0, 0, 0, NULL, 0, 0, 0),
(290, 'Nick', 'Novak', 'K', 'HOU', 11, 0, 0, 0, 0, NULL, 0, 0, 0),
(291, 'Mike', 'Nugent', 'K', 'CIN', 11, 0, 0, 0, 0, NULL, 0, 0, 0),
(292, 'Adam', 'Vinatieri', 'K', 'IND', 11, 0, 0, 0, 0, NULL, 0, 0, 0),
(293, 'Matt', 'Bryant', 'K', 'ATL', 10, 0, 0, 0, 0, NULL, 0, 0, 0),
(294, 'Nick', 'Folk', 'K', 'NYJ', 10, 0, 0, 0, 0, NULL, 0, 0, 0),
(295, 'Dustin', 'Hopkins', 'K', 'WAS', 10, 0, 0, 0, 0, NULL, 0, 0, 0),
(296, 'Wil', 'Lutz', 'K', 'NO', 10, 0, 0, 0, 0, NULL, 0, 0, 0),
(297, 'Mason', 'Crosby', 'K', 'GB', 9, 0, 0, 0, 0, NULL, 0, 0, 0),
(298, 'Josh', 'Lambo', 'K', 'SD', 9, 0, 0, 0, 0, NULL, 0, 0, 0),
(299, 'Cairo', 'Santos', 'K', 'KC', 9, 0, 0, 0, 0, NULL, 0, 0, 0),
(300, 'Caleb', 'Sturgis', 'K', 'PHI', 9, 0, 0, 0, 0, NULL, 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=301;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
