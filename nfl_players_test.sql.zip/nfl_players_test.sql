-- phpMyAdmin SQL Dump
-- version 4.6.1
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Oct 06, 2016 at 11:11 PM
-- Server version: 5.7.12
-- PHP Version: 5.6.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nfl_players_test`
--
CREATE DATABASE IF NOT EXISTS `nfl_players_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `nfl_players_test`;

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `team` varchar(255) DEFAULT NULL,
  `ff_points` float DEFAULT NULL,
  `pass_yds` int(11) DEFAULT NULL,
  `pass_tds` int(11) DEFAULT NULL,
  `rush_yds` int(11) DEFAULT NULL,
  `rush_tds` int(11) DEFAULT NULL,
  `rec_yds` int(11) DEFAULT NULL,
  `rec_tds` int(11) DEFAULT NULL,
  `intercepts` int(11) DEFAULT NULL,
  `fum` int(11) DEFAULT NULL,
  `pat` int(11) DEFAULT NULL,
  `fg19` int(11) DEFAULT NULL,
  `fg29` int(11) DEFAULT NULL,
  `fg39` int(11) DEFAULT NULL,
  `fg49` int(11) DEFAULT NULL,
  `fg50` int(11) DEFAULT NULL,
  `td` int(11) DEFAULT NULL,
  `sack` int(11) DEFAULT NULL,
  `safety` int(11) DEFAULT NULL,
  `pts_alw` int(11) DEFAULT NULL,
  `week` int(11) DEFAULT NULL,
  `year` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
